//SUÑIGA Maciel Joule Alexander
//VILLA Olivares Ariel
//NUÑEZ Martinez Marco Antonio
//Equipo 2
//=============================
namespace SistemaBiblioteca1
{
    // Longitud máxima de cada cuadro de texto = tamaño de su columna en MariaDB
    // (ver BaseDatos/Intercambio_libros.sql). Si cambias una columna, cambia aquí su límite.
    public static class LimitesCampos
    {
        public const int Id = 9;                // int: 9 dígitos caben siempre
        public const int Nombre = 60;           // Nombre / Apellido / Nacionalidad / País
        public const int NombreEditorial = 100;
        public const int UsuarioAcceso = 30;
        public const int Contrasena = 64;
        public const int Email = 100;
        public const int Descripcion = 200;     // Descripción de categoría
        public const int Motivo = 200;          // Motivo de sanción
        public const int MotivoEliminar = 150;  // Va dentro del historial del préstamo (255 con el texto fijo)
        public const int Monto = 11;            // DECIMAL(10,2): 8 enteros + punto + 2 decimales
        public const int Porcentaje = 4;        // 0.00 a 1.00
        public const int DiasRetraso = 4;
        public const int Busqueda = 100;
    }
}
