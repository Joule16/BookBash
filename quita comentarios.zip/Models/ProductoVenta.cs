﻿// ===============================
//   Equipo #2
//   NUÑEZ Martinez Marco Antonio
//   SUÑIGA Maciel Joule Alexander
//   VILLA Olivares Ariel
// ===============================
using System;

namespace SistemaBiblioteca1.Models
{
    // Resultado de una búsqueda del carrito: un libro con su precio y las existencias que hay ahora.
    // Stock = ejemplares activos y disponibles de ese libro.
    public class ProductoVenta
    {
        public int IdLibro { get; set; }

        public string Titulo { get; set; } = string.Empty;

        public string Isbn { get; set; } = string.Empty;

        public string Autor { get; set; } = string.Empty;

        // Precio de lista del libro (sin descuento).
        public decimal PrecioBase { get; set; }

        // Condición del grupo de ejemplares (Nuevo, Bueno, Regular, Dañado); vacío si no hay ejemplares.
        public string Condicion { get; set; } = string.Empty;

        public decimal DescuentoPorcentaje
        {
            get { return PoliticaDescuento.Porcentaje(Condicion); }
        }

        // Precio final: el precio base con el descuento de la condición ya aplicado.
        public decimal Precio
        {
            get { return PoliticaDescuento.Aplicar(PrecioBase, Condicion); }
        }

        public int Stock { get; set; }
    }
}
