//SUÑIGA Maciel Joule Alexander
//VILLA Olivares Ariel
//NUÑEZ Martinez Marco Antonio
//Equipo 2
//=============================
using System;

namespace SistemaBiblioteca1.Models
{
    // Descuento por condición del ejemplar. Las condiciones son las que permite la base de datos
    // (CK_Ejemplar_Condicion): Nuevo, Bueno, Regular y Dañado.
    // Para cambiar un descuento solo se edita el porcentaje en Porcentaje().
    public static class PoliticaDescuento
    {
        // Porcentaje de descuento (0 a 100) según la condición.
        public static decimal Porcentaje(string? condicion)
        {
            switch ((condicion ?? string.Empty).Trim())
            {
                case "Bueno":   return 15m;
                case "Regular": return 30m;
                case "Dañado":  return 50m;
                default:        return 0m;      // «Nuevo» o sin condición
            }
        }

        // Precio final = precio base menos el descuento, redondeado a centavos.
        public static decimal Aplicar(decimal precioBase, string? condicion)
        {
            decimal descuento = Porcentaje(condicion);
            return Math.Round(precioBase * (100m - descuento) / 100m, 2, MidpointRounding.AwayFromZero);
        }

        public static string Etiqueta(string? condicion)
        {
            decimal p = Porcentaje(condicion);
            return p > 0 ? "-" + p.ToString("0.##") + "%" : "—";
        }
    }
}
