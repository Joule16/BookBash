﻿//   Actividad 4.8 - Persistencia transaccional de pedidos
//   Equipo #2
//   NUÑEZ Martinez Marco Antonio
//   SUÑIGA Maciel Joule Alexander
//   VILLA Olivares Ariel
// ===============================
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace SistemaBiblioteca1.Models
{
    // Subdocumento embebido: una línea del pedido dentro del arreglo "Detalles".
    // También se usa para mostrar las líneas que vienen de MariaDB (INNER JOIN).
    public class DetallePedidoDoc
    {
        public int IdLibro { get; set; }

        public string Titulo { get; set; } = string.Empty;

        public string Condicion { get; set; } = string.Empty;

        public int Cantidad { get; set; }

        [BsonRepresentation(BsonType.Decimal128)]
        public decimal PrecioUnitario { get; set; }

        [BsonRepresentation(BsonType.Decimal128)]
        public decimal Subtotal { get; set; }
    }

    // Documento de la colección "Pedidos": el encabezado y sus líneas viajan juntos (relación 1:N embebida).
    // También se usa solo como encabezado cuando los datos vienen de MariaDB (Detalles vacío).
    public class PedidoDoc
    {
        [BsonId]
        public ObjectId Id { get; set; }

        // Mismo folio que Pedidos.IdPedido en MariaDB.
        public int IdPedido { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime Fecha { get; set; }

        public int? IdUsuario { get; set; }

        public string Cliente { get; set; } = string.Empty;

        [BsonRepresentation(BsonType.Decimal128)]
        public decimal Total { get; set; }

        public List<DetallePedidoDoc> Detalles { get; set; } = new List<DetallePedidoDoc>();
    }
}
