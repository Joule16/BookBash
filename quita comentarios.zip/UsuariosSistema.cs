﻿//   Equipo #2
//   NUÑEZ Martinez Marco Antonio
//   SUÑIGA Maciel Joule Alexander
//   VILLA Olivarez Ariel
// ===============================
using System;
using System.Collections.Generic;

namespace SistemaBiblioteca1
{
    public class CuentaSistema
    {
        public string NombreUsuario { get; }
        public string Contrasena { get; }
        public string NombreCompleto { get; }
        public string Rol { get; }

        public CuentaSistema(string nombreUsuario, string contrasena, string nombreCompleto, string rol)
        {
            NombreUsuario = nombreUsuario;
            Contrasena = contrasena;
            NombreCompleto = nombreCompleto;
            Rol = rol;
        }
    }

    public static class UsuariosSistema
    {
        public const string ROL_ADMINISTRADOR = "Administrador";
        public const string ROL_MODERADOR = "Moderador";

        // Usuario: persona registrada con cuenta (antes se llamaba "Invitado").
        public const string ROL_USUARIO = "Usuario";

        // Invitado: entra sin cuenta (botón "Entrar como invitado") y solo puede consultar.
        public const string ROL_INVITADO = "Invitado";

        private static readonly List<CuentaSistema> cuentas = new List<CuentaSistema>
        {
            new CuentaSistema("admin",    "Admin123", "Administrador del Sistema", ROL_ADMINISTRADOR),
            new CuentaSistema("operador", "Oper123",  "Moderador de Biblioteca",   ROL_MODERADOR)
        };

        public static bool ExisteUsuario(string nombreUsuario)
        {
            foreach (CuentaSistema cuenta in cuentas)
            {
                if (string.Equals(cuenta.NombreUsuario, nombreUsuario, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        public static CuentaSistema? Validar(string nombreUsuario, string contrasena)
        {
            foreach (CuentaSistema cuenta in cuentas)
            {
                if (string.Equals(cuenta.NombreUsuario, nombreUsuario, StringComparison.OrdinalIgnoreCase)
                    && cuenta.Contrasena == contrasena)
                {
                    return cuenta;
                }
            }
            return null;
        }
    }
}